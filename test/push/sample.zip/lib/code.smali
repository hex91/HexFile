.method public foo()V
  return-void
.end method
